<?php 
// what's OOP?
// Object-oriented programming
// Class
// Camel case

class User{
	// thuoc tinh
	public $name = "Canh";
	private $old;
	// phuong thuc
	public function getName(){
		echo "Canh";
	}
}
//khoi tao doi tuong User
$user = new User();
$user->getName();

//ke thua
class Student extends User{

}
//khoi tao doi tuong Student
$student = new Student();
$student->getName();
//





?>