<?php 
	/* Comment day la cau xin chao */
	// day cung la comment trong php
	//var a = 10;
	$a = 10;
	$b = 15;
	$c = $a * $b;

	echo $c;
	echo "<br/>";
	echo "Hello World!";
?>