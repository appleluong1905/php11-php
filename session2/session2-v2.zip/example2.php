<!DOCTYPE html>
<html>
<head>
	<title>Example 1 - Session 2</title>
</head>
<body>
	<h1>Form post</h1>
	<form action="register2.php" name = "register" method="get">
		<p>Name:<input type="text" name="name"></p>
		<p>Email:<input type="email" name="email"></p>
		<p><input type="submit" name="register" value="Register"></p>
	</form>
</body>
</html>