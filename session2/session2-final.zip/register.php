<?php 
	//var_dump($_POST);
	echo $_POST['name'];
	echo "<br>";
	echo $_POST['email'];
	//empty() va isset();
	// isset de kiem tra bien ton tai hay k
	// empty de kiem tra bien trong hay k? (trong thuong la NULL hoac "")
	// is_null() de kiem tra bien co NULL hay k?

?>