<?php 
// khoi dong session
session_start();

//gan gia tri session
$_SESSION['username'] = "2903018";


?>