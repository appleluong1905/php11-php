<?php 
// khoi dong session
session_start();

// goi session
echo $_SESSION['username'];
?>