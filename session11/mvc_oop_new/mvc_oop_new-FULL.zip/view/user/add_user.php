<h1>Add user</h1>
<form action ="index.php?action=add" method="post">
	<p>Name: <input type="text" name ="name"></p>
	<input type="submit" name="Add">
</form>