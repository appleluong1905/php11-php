<?php 
include 'controller/user_controller.php';
$checkRequest = new UserController;
$checkRequest->checkRequest();
?>