<?php 
include 'model/user_model.php';
class UserController {
	public function checkRequest(){
		//dinh nghia cac hanh dong voi user
		//1. List user: list
		//2. Add user: add
		//3. Edit user: edit
		//4. Delete user: delete
		// neu khong co action thi xem nhu dang list user
		$action = "";
		$action = isset($_GET['action'])?$_GET['action']:"list";
		switch ($action) {
			case 'list':
				$listUser = "";
		        $userModel = new UserModel;
		        $listUser = $userModel->getListUser();
		        include 'view/user/list_user.php';
				break;
			case 'edit';
				$idEdit = $_GET['id'];
				//viet ham edit o trong user model
				// goi va truyen id vao vao trong ham edit user
				//goi view edit user
				//kiem tra neu POST du lieu edit len thi thuc hien viec chinh sua du lieu

				break;
			case 'delete';
				$idDelete = $_GET['id'];
				//viet ham delete o trong user model
				$userModel = new UserModel();
				$userModel->deleteUser($idDelete);
				// goi va truyen id vao vao trong ham delete user
				//xoa thanh cong thi tro ve trang list_user
				header("Location: index.php");
				
				break;
			default:
				# code...
				break;
		}

	}
}
?>