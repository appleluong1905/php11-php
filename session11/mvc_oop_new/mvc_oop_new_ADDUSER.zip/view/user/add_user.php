<h1>Add user</h1>
<form>
	<p>Name: <input type="text"></p>
</form>