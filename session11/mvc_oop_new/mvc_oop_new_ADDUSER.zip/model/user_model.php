<?php 
include 'config/connectdb.php';
class UserModel extends ConnectDB{
	public function getListUser(){
		$sql = "SELECT * FROM users";
		$listUser = mysqli_query($this->conn,$sql);
		return $listUser;
	}
	public function deleteUser($id){
		$sql = "DELETE FROM users WHERE id = $id";
		mysqli_query($this->conn,$sql);
		
	}
}
?>